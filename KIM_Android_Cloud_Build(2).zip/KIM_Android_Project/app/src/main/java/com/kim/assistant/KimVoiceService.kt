package com.kim.assistant

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import android.provider.MediaStore
import android.net.Uri
import android.util.Log
import java.util.Locale

class KimVoiceService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var tts: android.speech.tts.TextToSpeech? = null
    private var listening = false
    private val channelId = "kim_voice"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = android.speech.tts.TextToSpeech(this) { result ->
            if (result == android.speech.tts.TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("es", "MX"))
            }
        }
        startForeground(7, notification("KIM está activa. Di: Oye KIM"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        beginListening()
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                channelId, "Escucha de KIM", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val pending = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, channelId)
            .setContentTitle("KIM")
            .setContentText(message)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("No encuentro un servicio de reconocimiento de voz en este teléfono.")
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { restartSoon() }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    process(words)
                    restartSoon()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val words = partialResults?.getStringArrayList(
                        SpeechRecognizer.RESULTS_RECOGNITION
                    )?.firstOrNull().orEmpty()
                    if (words.contains("oye kim", true)) {
                        say("Te escucho.")
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        listening = true
        listenOnce()
    }

    private fun listenOnce() {
        if (!listening) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { recognizer?.startListening(intent) } catch (e: Exception) { restartSoon() }
    }

    private fun restartSoon() {
        if (!listening) return
        Handler(Looper.getMainLooper()).postDelayed({ listenOnce() }, 900)
    }

    private fun process(raw: String) {
        val text = raw.lowercase(Locale("es", "MX")).trim()
        if (text.isBlank()) return
        if (text.contains("oye kim") || text == "kim") {
            say("Aquí estoy. ¿Qué necesitas?")
            return
        }
        if (text.startsWith("abre ") || text.startsWith("abrir ")) {
            val appName = text.removePrefix("abre ").removePrefix("abrir ").trim()
            if (!launchApp(appName)) say("No encontré esa aplicación.")
            return
        }
        if (text.contains("reproduce") || text.contains("pon música") || text.contains("pon video")) {
            playRecentMedia(text.contains("video") || text.contains("vídeo"))
            return
        }
        if (text.contains("detente") || text.contains("deja de escuchar")) {
            say("De acuerdo.")
            stopSelf()
            return
        }
        say("Te escuché decir: $raw. Todavía estoy aprendiendo ese comando.")
    }

    private fun launchApp(query: String): Boolean {
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val match = apps.firstOrNull {
            pm.getApplicationLabel(it).toString().contains(query, ignoreCase = true)
        } ?: return false
        val launch = pm.getLaunchIntentForPackage(match.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }

    private fun playRecentMedia(video: Boolean) {
        val collection = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                         else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.MediaColumns._ID)
        val cursor = try {
            contentResolver.query(collection, projection, null, null,
                MediaStore.MediaColumns.DATE_ADDED + " DESC")
        } catch (e: SecurityException) { null }
        cursor?.use {
            if (it.moveToFirst()) {
                val id = it.getLong(0)
                val uri = Uri.withAppendedPath(collection, id.toString())
                val mime = if (video) "video/*" else "audio/*"
                val view = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, mime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try { startActivity(view) } catch (_: Exception) { say("No hay reproductor disponible.") }
            } else say("No encontré archivos multimedia.")
        } ?: say("Necesito permiso para acceder a tus archivos multimedia.")
    }

    private fun say(message: String) {
        tts?.speak(message, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "kim")
    }

    override fun onDestroy() {
        listening = false
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
