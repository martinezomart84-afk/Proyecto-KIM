package com.kim.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.*
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(3, 10, 25)
        window.navigationBarColor = Color.rgb(3, 10, 25)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(3, 10, 25))
        }
        val title = TextView(this).apply {
            text = "KIM"
            textSize = 42f
            setTextColor(Color.rgb(65, 210, 255))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Tu asistente personal"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Lista para ayudarte"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 28)
        }
        layout.addView(title, match())
        layout.addView(subtitle, match())
        layout.addView(status, match())

        addButton(layout, "ACTIVAR «OYE KIM»") {
            if (hasAudioPermission()) startKimService()
            else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
        addButton(layout, "DETENER ESCUCHA") {
            stopService(Intent(this, KimVoiceService::class.java))
            status.text = "Escucha detenida"
        }
        addButton(layout, "PROBAR VOZ") {
            speak("Hola, soy KIM. Estoy lista para ayudarte.")
        }
        addButton(layout, "ABRIR ARCHIVOS") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(i, 22)
        }
        addButton(layout, "AJUSTES DE VOZ") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(10, 75, 110))
            setOnClickListener { action() }
        }
        val p = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 10, 0, 10) }
        parent.addView(b, p)
    }

    private fun hasAudioPermission() =
        Build.VERSION.SDK_INT < 23 ||
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun startKimService() {
        val intent = Intent(this, KimVoiceService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        status.text = "KIM está escuchando «Oye KIM»"
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kim-test")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("es", "MX"))
            if (result == TextToSpeech.LANG_MISSING_DATA ||
                result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale("es", "US")
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) startKimService()
        else status.text = "Necesito permiso de micrófono para escuchar"
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
