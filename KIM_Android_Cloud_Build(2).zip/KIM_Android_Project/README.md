# KIM para Android

Proyecto inicial Android Studio para Nubia Focus Pro / Android 13+.

## Compilar el APK desde el teléfono usando GitHub Actions

Este proyecto incluye un flujo de compilación en la nube. No necesitas instalar Android Studio ni tener una computadora.

1. En el teléfono, abre https://github.com y crea una cuenta o inicia sesión.
2. Crea un repositorio nuevo. Puedes llamarlo `KIM-Android`. Para mayor privacidad, elige **Private**.
3. En el repositorio, usa **Add file > Upload files** y sube el contenido de esta carpeta extraída, incluyendo la carpeta oculta `.github` y el archivo `.github/workflows/android.yml`.
   - Si el selector de archivos no muestra `.github`, usa el navegador en modo escritorio o crea primero las carpetas y el archivo desde la web de GitHub.
4. Pulsa **Commit changes**.
5. Abre la pestaña **Actions**, selecciona **Build KIM APK** y espera a que el proceso termine en verde.
6. Abre la ejecución completada, baja hasta **Artifacts** y descarga `KIM-debug-apk`.
7. Extrae ese ZIP. Dentro estará `app-debug.apk`. Tócalo para instalarlo y acepta la instalación desde esa fuente si Android lo solicita.

## Funciones del prototipo
- Interfaz sencilla estilo futurista.
- Voz de salida configurada en `es-MX` (la voz concreta depende del motor TTS instalado).
- Servicio en primer plano con notificación para reconocimiento de voz.
- Detección aproximada de la frase «Oye KIM».
- Apertura de aplicaciones por coincidencia de nombre.
- Reproducción del archivo de audio o vídeo más reciente mediante una app reproductora.
- Selector del sistema para abrir archivos.

## Limitaciones importantes
- «Oye KIM» se detecta mediante el reconocimiento de voz de Android, no mediante un motor dedicado de palabra clave siempre activo. No garantiza escucha continua: Android, el proveedor de voz, la batería y las restricciones del fabricante pueden interrumpirla.
- El reconocimiento puede requerir Internet y depende del servicio de voz instalado. La voz de salida usa el motor TTS del teléfono; instala una voz española de México en Ajustes si está disponible.
- Para audio y vídeo, Android requiere permisos. El acceso general a todos los archivos no se concede automáticamente; se usa el selector seguro del sistema.
- Este es un prototipo inicial, no una versión final probada en el Nubia. El APK de depuración no está firmado para distribución pública.
